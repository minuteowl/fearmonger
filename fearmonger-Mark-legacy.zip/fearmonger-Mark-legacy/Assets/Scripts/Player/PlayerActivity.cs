﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Selector))]
public class PlayerActivity : MonoBehaviour {

	GameManager game;
	Leveling level;
	
	// Attached scripts
	[HideInInspector] public Selector grab;
	private Transform grabTransform;
	
	// Actions
	MonoBehaviour[] args = new MonoBehaviour[10];
	[HideInInspector] public Ability currentAbility;
	AbilityMenu abilityMenu;
	
	// Sprites
	Sprite[] sprites;
	int spriteIndex=0;
	public bool IsInvisible = false;
	
	public void SetAbility(Ability a) {
		currentAbility = a;
	}

	public void MoveTo(Vector3 pos) {
		Debug.Log("Move to ("+pos.x+", "+pos.y+")");
		transform.position = new Vector3(pos.x,pos.y,transform.position.z);
	}

	// Use this for initialization
	void Start () {
		grabTransform = transform.FindChild("Selector");
		grab = grabTransform.GetComponent<Selector>();
		game = GameObject.Find ("GameManager").GetComponent<GameManager>();
		level = transform.GetComponent<Leveling>();
		abilityMenu = transform.GetComponent<AbilityMenu>();
		game.currentView = GameManager.View.Game;
	}

	void EnterRoom()
	{
		Statics.LockInput=true;
	}


	void Update() {
		if (!Statics.LockInput) {
			UpdateInput();
		}
	}

	void UpdateAbilities() {
		Statics.LockInput=true; // make sure that the ability is only called once at a time
		if (level.CanUse(currentAbility)) {
			level.UseAbility(currentAbility);
			grab.SetWait(currentAbility.Duration);
			if (currentAbility is Ability_Push)
			{
			
				GameObject tentacleObj, instance;
				PushTentacle tentacle;
				tentacleObj = Resources.Load<GameObject>("Generated/AbilityFX/Tentacle_short");
				instance = GameObject.Instantiate(tentacleObj,gameObject.transform.position, gameObject.transform.rotation) as GameObject;


				//args[0]=grab;
				//currentAbility.UseAbility (level, args);
			}
			else if (currentAbility is Ability_Flash)
			{
				args[0] = game.currentRoom;
				currentAbility.UseAbility (level, args);
			}
			else if (currentAbility is Ability_Tentacle)
			{
				// set args
				currentAbility.UseAbility(level,args);
			}
			else if (currentAbility is Ability_ShadowStorm)
			{
				// set args
				currentAbility.UseAbility(level,args);
			}
		}
	}
	
	// Update is called once per frame
	void UpdateInput () {
		if (game.currentView==GameManager.View.Game){
			//UpdateSelector();
			if (PlayerInput.InputAction()) {
				Statics.LockInput=true;
				if (grab.isHolding) {
					if (grab.currentFocus==Selector.FocusType.None) {
						grab.Drop();
					}
					else {
						Debug.Log("Can't drop that here.");
					}
				}
				else { // Is not holding anything
					if (grab.currentFocus==Selector.FocusType.Door) {
						game.GoToMap();
					}
					else if (grab.currentFocus==Selector.FocusType.Movable) {
						grab.Pickup();
					}
					else {
						UpdateAbilities();
					}
				}
			}
			else if (PlayerInput.InputStatMenu()){
				Statics.LockInput=true;
				game.Pause ();
				abilityMenu.Prepare();
				game.currentView=GameManager.View.Stats;
			}
			else
			{
				Statics.LockInput=true;
			}
		}
		else if (game.currentView==GameManager.View.Stats) {
			// this will go in the AbilityMenu class
		}
	}
}