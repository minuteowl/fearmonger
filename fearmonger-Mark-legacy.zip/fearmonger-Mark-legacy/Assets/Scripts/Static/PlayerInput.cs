﻿using UnityEngine;
using System.Collections;

public static class PlayerInput {

	// Functions with input
	public static Vector3 Mouse2D(Vector3 v) {
		Camera cam = Camera.main;
		Vector3 u = cam.ScreenToWorldPoint(Input.mousePosition);
		return new Vector3(u.x,u.y,v.z);
	}
	
	
	public static bool IsInViewport(Vector3 v) {
		Camera cam = Camera.main;
		v = cam.WorldToScreenPoint(v);
		if (v.x < cam.pixelRect.xMin) return false;
		else if (v.x > cam.pixelRect.xMax) return false;
		else if (v.y < cam.pixelRect.yMin) return false;
		else if (v.y > cam.pixelRect.yMax) return false;
		else return true;
	}


	// Functions to normalize keyboard input
	public static bool InputRight()
	{
		return (Input.GetKey("right") && !Input.GetKey("left"));
	}

	public static bool InputRightOnce()
	{
		return (Input.GetKeyDown("right") && !Input.GetKey("left"));
	}

	public static bool InputQuit()
	{
		return (Input.GetKeyDown("escape"));
	}

	public static bool InputLeft()
	{
		return (Input.GetKey("left") && !Input.GetKey("right"));
	}

	public static bool InputLeftOnce()
	{
		return (Input.GetKeyDown("left") && !Input.GetKey("right"));
	}

	public static bool InputUp()
	{
		return (Input.GetKey("up") && !Input.GetKey("down"));
	}

	public static bool InputUpOnce()
	{
		return (Input.GetKeyDown("up") && !Input.GetKey("down"));
	}

	public static bool InputDown()
	{
		return (Input.GetKey("down") && !Input.GetKey("up"));
	}

	public static bool InputDownOnce()
	{
		return (Input.GetKeyDown("down") && !Input.GetKey("up"));
	}
	
	public static bool InputAction()
	{
		//return (Input.GetKeyDown ("space"));
		return (Input.GetMouseButtonDown (0));
	}

	public static bool InputInvisible()
	{
		return (Input.GetKeyDown("c"));
	}

	public static bool InputMapMenu()
	{
		return (Input.GetKeyDown("x") && !Input.GetKeyDown("z"));
	}

	public static bool InputStatMenu()
	{
		//return (Input.GetKeyDown("z"));
		return (Input.GetMouseButtonDown (1));
	}
}
