﻿using UnityEngine;
using System.Collections;

public static class Statics {

	public static bool LockInput=false;

	public static bool LoadingRoom=false;

	public static float Tick = 1f;
}
