﻿using UnityEngine;
//using System.Collections.Generic;

public class GameManager : MonoBehaviour {


	bool CursorMode=true;
	
	Transform targetTransform;


	// GLOBAL VARIABLES GO HERE:
	public enum View { Start, Game, Map, Stats}
	public View currentView;
	PlayerActivity player;
	public int NumOccupiedRooms=0;
	public bool IsPaused=false;

	// CAMERA LOGIC
	[HideInInspector] public CameraObject cameraObject;
	Transform cameraMapPositionTransform;

	// ROOMS
	public RoomObject currentRoom, lastRoom;
	Transform[,] squares;
	RoomObject[,] roomObjects;
	float selectedRoomMarkerZ;
	int[,] PeoplePerRoom;
	int i,j;
	[HideInInspector] public int row=0, col=0;
	float upBound, leftBound, rightBound, downBound;

	public bool locked;

	float countdown, countdownMax=5f;

	public void Pause(){
		Time.timeScale=0f;
		IsPaused=true;
	}
	public void Unpause(){
		Time.timeScale=1f;
		IsPaused=false;
	}

	void Start ()
	{
		countdown = countdownMax; // Initial countdown is shorter than others
		cameraObject = GameObject.FindGameObjectWithTag("MainCamera").transform.GetComponent<CameraObject>();
		player  = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerActivity>();
		squares = new Transform[4,4];
		roomObjects = new RoomObject[4,4];
		PeoplePerRoom = new int[4,4];
		for (i=0; i<4; i++)  for (j=0; j<4; j++) {
			squares[i,j] = GameObject.Find("Room "+(i+1)+"0"+(j+1)).transform;
			roomObjects[i,j] = (RoomObject)squares[i,j].GetComponent<RoomObject>();
		}
		currentRoom = roomObjects[0,0];
		//GoToRoom(currentRoom);
	}


	public void GoToRoom(RoomObject room)
	{
		Unpause();
		if (currentView==View.Map) {
			Debug.Log("Go to room "+room.RoomName);
			player.MoveTo(room.entryLoc);
			//currentView = View.Game;
			cameraObject.ZoomIn(room);
		}
	}


	public void GoToMap() {
		Pause ();
		if (currentView==View.Game) {
			lastRoom = currentRoom;
			cameraObject = GameObject.FindGameObjectWithTag("MainCamera").transform.GetComponent<CameraObject>();
			currentView = View.Map;
			cameraObject.ZoomOut();
		}
	}

	void OnGUI(){
		if (currentView == View.Map) {
			//Floor 1
			if (GUI.Button (new Rect (Screen.width * .225f, Screen.height * .635f, Screen.width * .07f, Screen.height * .1f), "R101")) {
				buttonInteract(0,0);
			}	
			if (GUI.Button (new Rect (Screen.width * .32f, Screen.height * .635f, Screen.width * .07f, Screen.height * .1f), "R102")) {
				buttonInteract(0,1);
			}
			if (GUI.Button (new Rect (Screen.width * .413f, Screen.height * .635f, Screen.width * .07f, Screen.height * .1f), "R103")) {
				buttonInteract(0,2);
			}
			if (GUI.Button (new Rect (Screen.width * .508f, Screen.height * .635f, Screen.width * .07f, Screen.height * .1f), "R104")) {
				buttonInteract(0,3);
			}

			//Floor 2
			if (GUI.Button (new Rect (Screen.width * .225f, Screen.height * .47f, Screen.width * .07f, Screen.height * .1f), "R201")) {
				buttonInteract(1,0);
			}	
			if (GUI.Button (new Rect (Screen.width * .32f, Screen.height * .47f, Screen.width * .07f, Screen.height * .1f), "R202")) {
				buttonInteract(1,1);
			}
			if (GUI.Button (new Rect (Screen.width * .413f, Screen.height * .47f, Screen.width * .07f, Screen.height * .1f), "R203")) {
				buttonInteract(1,2);
			}
			if (GUI.Button (new Rect (Screen.width * .508f, Screen.height * .47f, Screen.width * .07f, Screen.height * .1f), "R204")) {
				buttonInteract(1,3);
			}

			//Floor 3
			if (GUI.Button (new Rect (Screen.width * .225f, Screen.height * .302f, Screen.width * .07f, Screen.height * .1f), "R301")) {
				buttonInteract(2,0);
			}	
			if (GUI.Button (new Rect (Screen.width * .32f, Screen.height * .302f, Screen.width * .07f, Screen.height * .1f), "R302")) {
				buttonInteract(2,1);
			}
			if (GUI.Button (new Rect (Screen.width * .413f, Screen.height * .302f, Screen.width * .07f, Screen.height * .1f), "R303")) {
				buttonInteract(2,2);
			}
			if (GUI.Button (new Rect (Screen.width * .508f, Screen.height * .302f, Screen.width * .07f, Screen.height * .1f), "R304")) {
				buttonInteract(2,3);
			}

			//Floor 4
			if (GUI.Button (new Rect (Screen.width * .225f, Screen.height * .135f, Screen.width * .07f, Screen.height * .1f), "R401")) {
				buttonInteract(3,0);
			}	
			if (GUI.Button (new Rect (Screen.width * .32f, Screen.height * .135f, Screen.width * .07f, Screen.height * .1f), "R402")) {
				buttonInteract(3,1);
			}
			if (GUI.Button (new Rect (Screen.width * .413f, Screen.height * .135f, Screen.width * .07f, Screen.height * .1f), "R403")) {
				buttonInteract(3,2);
			}
			if (GUI.Button (new Rect (Screen.width * .508f, Screen.height * .135f, Screen.width * .07f, Screen.height * .1f), "R404")) {
				buttonInteract(3,3);
			}
		}
	}

	void buttonInteract(int row, int column){
		Statics.LockInput = true;
		currentRoom = roomObjects[row,column];
		Debug.Log("Going to room "+currentRoom.RoomName);
		Statics.LockInput=false;
		GoToRoom(currentRoom);
		lastRoom = currentRoom;
		currentView = View.Game;
	}

	/*
	void MoveMarker()
	{
		Statics.LockInput = true;
		currentRoom = roomObjects[row,col];
		player.transform.position = new Vector3(currentRoom.entryLoc.x,
		                                          currentRoom.entryLoc.y,
		                                          player.transform.position.z);
	}
	*/

	void UpdateInput() {

	}

	void Update() {
		if (!IsPaused && NumOccupiedRooms<4) {
			if (countdown > 0f) {
				countdown -= Statics.Tick*Time.deltaTime;
			}
			else {
				for (i=0;i<4;i++) for (j=0;j<4;j++) {
					if (roomObjects[i,j]!=currentRoom && roomObjects[i,j].numberOccupants==0 && roomObjects[i,j].Ready)
					{
						roomObjects[i,j].CheckIn();
						i=5; j=5;
						countdown = countdownMax;
					}
				}
			}
		}
		if (currentView==View.Map) {
			for (i=0; i<4; i++)  for (j=0; j<4; j++) {
				PeoplePerRoom[i,j] = roomObjects[i,j].numberOccupants;
			}
			if (!currentRoom) {
				currentRoom = roomObjects[row,col];
			}
			/*
			if (!Statics.LockInput) {
				if (PlayerInput.InputLeftOnce() && col>0) {
					col--; MoveMarker(); Statics.LockInput=true;
				}
				else if (PlayerInput.InputRightOnce() && col<3) {
					col++; MoveMarker(); Statics.LockInput=true;
				}
				else if (PlayerInput.InputUpOnce() && row<3) {
					row++; MoveMarker(); Statics.LockInput=true;
				}
				else if (PlayerInput.InputDownOnce() && row>0){
					row--; MoveMarker(); Statics.LockInput=true;
				}
				else if (PlayerInput.InputAction())
				{
					Debug.Log("Going to room "+currentRoom.RoomName);
					Statics.LockInput=false;
					GoToRoom(currentRoom);
					lastRoom = currentRoom;
					currentView = View.Game;
				}
			}
			*/
		}
		if (Statics.LockInput) {
			Statics.LockInput = false;
		}
		locked=Statics.LockInput;

	}

}