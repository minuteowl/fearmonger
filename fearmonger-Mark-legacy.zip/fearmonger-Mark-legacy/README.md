fearmonger
==========

Project for UMBC art/computer science class.
